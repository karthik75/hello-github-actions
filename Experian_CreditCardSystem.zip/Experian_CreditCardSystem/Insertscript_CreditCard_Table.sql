INSERT INTO [dbo].[CreditCard]
           ([Name]
           ,[APR]
           ,[PromotionalMessage]
           ,[AnnualIncomeLimit])
     VALUES
           ('Barclaycard'
           ,'30.1'
           ,'30% offer for your first purchase'
           ,30000)

INSERT INTO [dbo].[CreditCard]
           ([Name]
           ,[APR]
           ,[PromotionalMessage]
           ,[AnnualIncomeLimit])
     VALUES
           ('Vanquis card'
           ,'50.5'
           ,'20% discount on your Air Travel'
           ,0)
GO



