﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using ExperianDAL.Model;



namespace ExperianDAL
{
    public class CreditCardDbContext: DbContext
    {
        public CreditCardDbContext(DbContextOptions<CreditCardDbContext> options) : base(options)
        {

        }
        public DbSet<Customer> Customer { get; set; }
        public DbSet<CreditCard> CreditCard { get; set; }
        public DbSet<CustomerCreditCard> CustomerCreditCard { get; set; }
    }
}
