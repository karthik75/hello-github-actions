﻿using ExperianDAL.IRepoository;
using ExperianDAL;
using ExperianDAL.Model;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;

namespace ExperianDAL.Repoository
{
    public class CreditCardRepository: ICreditCardRepository
    {
        private readonly CreditCardDbContext _dbContext;
        private readonly ILogger<CreditCardRepository> _logger;


        public CreditCardRepository(CreditCardDbContext dbContext, ILogger<CreditCardRepository> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        /// <summary>
        /// Get Credit card information based on Customer data
        /// </summary>
        /// <param name="customer"></param>
        /// <returns></returns>
        public CreditCard GetCreditCardByCustomer(Customer customer)
        {
            try
            {
                //Get Credit Card Details based on Customer Annual Income of Customer
                var creditCard = _dbContext.CreditCard.Where(cc => customer.AnnualIncome >= cc.AnnualIncomeLimit).FirstOrDefault();
                return creditCard;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Customer Service: Failed to get CreditCard data: {ex}");
                return null;
            }
        }
    }
}
