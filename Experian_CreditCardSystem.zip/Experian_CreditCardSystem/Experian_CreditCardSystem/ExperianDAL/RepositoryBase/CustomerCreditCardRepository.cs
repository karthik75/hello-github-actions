﻿using ExperianDAL.IRepoository;
using ExperianDAL;
using ExperianDAL.Model;
using Microsoft.Extensions.Logging;
using System;

namespace ExperianDAL.Repoository
{
    public class CustomerCreditCardRepository : ICustomerCreditCardRepository
    {
        private readonly CreditCardDbContext _dbContext;
        private readonly ILogger<CustomerCreditCardRepository> _logger;

        public CustomerCreditCardRepository(CreditCardDbContext dbContext, ILogger<CustomerCreditCardRepository> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        /// <summary>
        ///  Save customer Pre-qualification Information
        /// </summary>
        /// <param name="customerCreditCard"></param>
        /// <returns></returns>
        public CustomerCreditCard Add(CustomerCreditCard customerCreditCard)
        {
            try
            {
                // Save Customer Credit Card details to database
                _dbContext.CustomerCreditCard.Add(customerCreditCard);
                _dbContext.SaveChanges();
                return customerCreditCard;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to add Customer CreditCard data: {ex}");
                return null;
            }
        }

    }
}
