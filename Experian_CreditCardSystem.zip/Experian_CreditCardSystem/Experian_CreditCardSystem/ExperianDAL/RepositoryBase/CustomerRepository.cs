﻿using ExperianDAL.IRepoository;
using ExperianDAL;
using ExperianDAL.Model;
using Microsoft.Extensions.Logging;
using System;

namespace ExperianDAL.Repoository
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly CreditCardDbContext _dbContext;
        private readonly ILogger<CustomerRepository> _logger;

        public CustomerRepository(CreditCardDbContext dbContext, ILogger<CustomerRepository> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        /// <summary>
        /// Save Customer Information
        /// </summary>
        /// <param name="customer"></param>
        /// <returns></returns>
        public Customer Add(Customer customer)
        {
            try
            {
                // Save Customer details to database
                _dbContext.Customer.Add(customer);
                _dbContext.SaveChanges();
                return customer;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to add Customer data: {ex}");
                return null;
            }
        }

    }
}
