﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ExperianDAL.Model
{
    public class CreditCard
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Column(TypeName = "varchar(50)")]
        public string Name { get; set; }

        [Required]
        [Column(TypeName = "decimal(7,2)")]
        public decimal APR { get; set; }

        [Required]
        [Column(TypeName = "varchar(200)")]
        public string PromotionalMessage { get; set; }

        [Required]
        [Column(TypeName = "decimal(9,2)")]
        public decimal AnnualIncomeLimit { get; set; }
    }
}
