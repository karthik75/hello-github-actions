﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ExperianDAL.Model
{
    public class CustomerCreditCard
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [ForeignKey("Customer")]
        public int CustomerId { get; set; }
        public virtual Customer Customer { get; set; }

        [Required]
        [ForeignKey("CreditCard")]
        public int CreditCardId { get; set; }
        public virtual CreditCard CreditCard { get; set; }
    }
}
