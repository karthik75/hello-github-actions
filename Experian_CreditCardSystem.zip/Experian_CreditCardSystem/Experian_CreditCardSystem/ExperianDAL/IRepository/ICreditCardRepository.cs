﻿using ExperianDAL.Model;

namespace ExperianDAL.IRepoository
{
    public interface ICreditCardRepository
    {
        public CreditCard GetCreditCardByCustomer(Customer customer);
    }
}
