﻿using ExperianDAL.Model;

namespace ExperianDAL.IRepoository
{
    public interface ICustomerRepository
    {
        public Customer Add(Customer customer);

    }
}
