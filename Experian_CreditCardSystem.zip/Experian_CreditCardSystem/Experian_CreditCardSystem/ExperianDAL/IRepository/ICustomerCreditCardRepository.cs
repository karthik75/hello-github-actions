﻿using ExperianDAL.Model;

namespace ExperianDAL.IRepoository
{
    public interface ICustomerCreditCardRepository
    {
        public CustomerCreditCard Add(CustomerCreditCard customerCreditCard);

    }
}
