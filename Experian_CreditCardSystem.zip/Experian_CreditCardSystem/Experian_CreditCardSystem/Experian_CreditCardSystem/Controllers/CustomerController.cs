﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Experian.Business.Services;
using Experian.ViewModel;

namespace Experian_CreditCardSystem.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ICustomerService _customerService;
        private readonly ILogger<CustomerController> _logger;

        public CustomerController(ICustomerService customerService, ILogger<CustomerController> logger)
        {
            _customerService = customerService;
            _logger = logger;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(CustomerVM customer)
        {
            try
            {
                CustomerVM newCustomer = new CustomerVM();
                //Check for model validation errors
                if (ModelState.IsValid)
                {
                    //Saving Customer Details for valid customers
                    newCustomer = _customerService.SaveCustomerDetails(customer);
                    return View("CreditCard", newCustomer);                
                   
                }
                else
                {
                    return View(customer);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to get CreditCard data: {ex}");
                return null;
            }
        }       
    
}
}
