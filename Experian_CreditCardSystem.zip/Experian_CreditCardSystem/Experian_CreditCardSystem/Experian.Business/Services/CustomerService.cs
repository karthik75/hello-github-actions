﻿using ExperianDAL.IRepoository;
using ExperianDAL.Model;
using Experian.ViewModel;
using Microsoft.Extensions.Logging;
using System;

namespace Experian.Business.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly ICreditCardRepository _creditCardRepository;
        private readonly ICustomerCreditCardRepository _customerCreditCardRepository;
        private readonly ILogger<CustomerService> _logger;

        public CustomerService(ICustomerRepository customerRepository, ICreditCardRepository creditCardRepository, ICustomerCreditCardRepository customerCreditCardRepository, ILogger<CustomerService> logger)
        {
            _customerRepository = customerRepository;
            _creditCardRepository = creditCardRepository;
            _customerCreditCardRepository = customerCreditCardRepository;
            _logger = logger;
        }

        /// <summary>
        ///  Save Customer details along with Credit card details
        /// </summary>
        /// <param name="customerVM"></param>
        /// <returns></returns>
        public CustomerVM SaveCustomerDetails(CustomerVM customerVM)
        {
            try
            {
                if (customerVM != null)
                {
                    //Save Customer Details to Database
                    customerVM = SaveCustomer(customerVM);

                    //Create credit card details, if customer is valid & is eligible based on age 
                    if (customerVM.Id > 0 && customerVM.IsEligible)
                    {
                        // Get Credit Card Details from database based on customer details
                        var customerCreditCardDAL = GetCreditCardByAnnualIncome(customerVM);

                        if (customerCreditCardDAL != null)
                        {
                            CreditCardVM customerCreditCardVM = new CreditCardVM
                            {
                                CreditCardId = customerCreditCardDAL.Id,
                                CreditCardName = customerCreditCardDAL.Name,
                                CreditCardAPR = customerCreditCardDAL.APR,
                                CreditCardPromotionalMessage = customerCreditCardDAL.PromotionalMessage
                            };

                            customerVM.CustomerCreditCard = customerCreditCardVM;

                            // Saving Customer Credit Card information in the database
                            SaveCustomerCardDetails(customerVM);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to Save Customer PreQualification Data: {ex}");
                return null;
            }
            return customerVM;
        }

        /// <summary>
        /// Save Customer Details to customer table
        /// </summary>
        /// <param name="customerVM"></param>
        /// <returns></returns>
        private CustomerVM SaveCustomer(CustomerVM customerVM)
        {
            if (customerVM != null)
            {
                Customer customerDAL = new Customer
                {
                    FirstName = customerVM.FirstName,
                    LastName = customerVM.LastName,
                    DOB = customerVM.DateOfBirth,
                    AnnualIncome = customerVM.AnnualIncome,
                    // Validation for credit card based on Age
                    IsEligible = IsCustomerEligible(customerVM)
                };

                _customerRepository.Add(customerDAL);

                //Assigning newly created Customer details to Customer view model
                customerVM.Id = customerDAL.Id;
                customerVM.IsEligible = customerDAL.IsEligible;
            }

            return customerVM;
        }

        /// <summary>
        ///  Check whether the customer is eligible for a credit card based on age criteria
        /// </summary>
        /// <param name="customerVM"></param>
        /// <returns></returns>
        private bool IsCustomerEligible(CustomerVM customerVM)
        {
            bool isEligible = false;
            if (customerVM != null)
            {
                // Calculating Age of the customer by substracting year of birth of the customer from current year 
                int age = DateTime.Now.Year - customerVM.DateOfBirth.Year;
                if (DateTime.Now.DayOfYear < customerVM.DateOfBirth.DayOfYear)
                    age -= 1;

                if (age >= 18)
                {
                    // If age is greater than or equal to 18 assigning IsEligible prperty to true
                    isEligible = true;
                }
            }

            return isEligible;

        }

        /// <summary>
        /// Get the credit card details from the database based on customer's annual income
        /// </summary>
        /// <param name="customerVM"></param>
        /// <returns></returns>
        private CreditCard GetCreditCardByAnnualIncome(CustomerVM customerVM)
        {

            Customer customerDAL = new Customer
            {
                Id = customerVM.Id,
                FirstName = customerVM.FirstName,
                LastName = customerVM.LastName,
                DOB = customerVM.DateOfBirth,
                AnnualIncome = customerVM.AnnualIncome,
                // Validation for Customer for credit card based on Age Eligibility Criteria
                IsEligible = IsCustomerEligible(customerVM)
            };

            // Getting Credit Card details based on Annual Income eligibility criteria
            var creditCard = _creditCardRepository.GetCreditCardByCustomer(customerDAL);

            return creditCard;
        }

        /// <summary>
        /// Save Customer Credit card information once the customer gets a pre-qualifed credit card based on rule
        /// </summary>
        /// <param name="customerVM"></param>
        /// <returns></returns>
        private CustomerVM SaveCustomerCardDetails(CustomerVM customerVM)
        {
            if (customerVM != null && customerVM.CustomerCreditCard != null)
            {
                CustomerCreditCard customerCreditCardDAL = new CustomerCreditCard
                {
                    CustomerId = customerVM.Id,
                    CreditCardId = customerVM.CustomerCreditCard.CreditCardId
                };
                
                //Saving Pre-qualified customer credit Card information to database
                _customerCreditCardRepository.Add(customerCreditCardDAL);

                //Assigning newly created Customer credit details to Customer View Model property
                customerVM.CustomerCreditCard.Id = customerCreditCardDAL.Id;
            }

            return customerVM;
        }
    }
}
