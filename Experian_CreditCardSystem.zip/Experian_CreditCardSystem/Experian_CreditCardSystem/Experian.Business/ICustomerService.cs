﻿using Experian.ViewModel;

namespace Experian.Business.Services
{
    public interface ICustomerService
    {
        public CustomerVM SaveCustomerDetails(CustomerVM customer);
    }
}
