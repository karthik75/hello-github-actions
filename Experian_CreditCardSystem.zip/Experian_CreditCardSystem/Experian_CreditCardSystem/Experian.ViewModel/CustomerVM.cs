﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Experian.ViewModel
{
    public class CustomerVM
    {
        public int Id { get; set; }

        [Required]
        [DisplayName("First Name")]
        [MaxLength(25)]
        public string FirstName { get; set; }

        [Required]
        [DisplayName("Last Name")]
        [MaxLength(25)]
        public string LastName { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        [DisplayName("DOB")]
        public DateTime DateOfBirth { get; set; }

        [Required]
        [Range(0, 99999.99, ErrorMessage = "Invalid Annual Income; Max 5 digits")]
        [DisplayName("Annual Income")]
        public decimal AnnualIncome { get; set; }

        public bool IsEligible { get; set; }

        public CreditCardVM CustomerCreditCard { get; set; }

    }
}
