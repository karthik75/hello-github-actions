﻿namespace Experian.ViewModel
{
    public class CreditCardVM
    {
        public int CreditCardId { get; set; }
        public string CreditCardName { get; set; }
        public decimal CreditCardAPR { get; set; }
        public string CreditCardPromotionalMessage { get; set; }
        public int Id { get; set; }
    }
}
